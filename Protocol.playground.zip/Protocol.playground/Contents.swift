protocol WaterObjects {
    func velocity ()-> String
    func size (height:Float, width:Float) -> Float
    func color ()-> String
}

extension WaterObjects{
    func size (height:Float, width:Float) -> Float{
        height/width
    }
    
}
class MechanicalAquatics: WaterObjects{
    func velocity() -> String {
        "Eu consigo atingir 150km por minuto"
    }
    
    func color() -> String {
        "Eu sou Dourado"
    }
 
}

class OrganicAquatic: WaterObjects{
    func velocity() -> String {
        "Eu consigo atingir 10km por minuto"
    }
    
    func color() -> String {
        "Eu sou Preto e Dourado"
    }
    
}

let mecanic = MechanicalAquatics()
let organic = OrganicAquatic()


print(mecanic.color())
print(mecanic.velocity())
print(mecanic.size(height:10,width:20))


print(organic.color())
print(organic.velocity())
print(organic.size(height: 1000, width: 300))
